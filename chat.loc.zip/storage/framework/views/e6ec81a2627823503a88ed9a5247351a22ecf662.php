<?php $__currentLoopData = $chatUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chatUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li style="list-style: none">
        <a href="/chat/<?php echo e($chatUser->id); ?>" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center <?php if(isset($chatObj['toUser']->id) && $chatObj['toUser']->id == $chatUser->id): ?> list-group-item-secondary isActive <?php endif; ?>">
            <?php echo e($chatUser->email); ?>

            <?php if($chatUser->newCount > 0): ?>
                <span class="badge badge-primary badge-pill"><?php echo e($chatUser->newCount); ?></span>
            <?php endif; ?>
        </a>
    </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>