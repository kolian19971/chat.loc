<?php $__env->startSection('meta'); ?>
    <meta name="toUserId" content="<?php echo e(isset($chatObj['toUser']->id) ? $chatObj['toUser']->id : 0); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <div class="container">
        <div class="row mt-5">

            <?php if(count($chatUsers)): ?>

                <div class="col-md-3">

                    <div class="card">

                        <ul class="list-group" id="chatUsers">

                            <?php $__currentLoopData = $chatUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chatUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li style="list-style: none">
                                    <a href="/chat/<?php echo e($chatUser->id); ?>"
                                       class="list-group-item list-group-item-action d-flex justify-content-between align-items-center <?php if(isset($chatObj['toUser']->id) && $chatObj['toUser']->id == $chatUser->id): ?> list-group-item-secondary isActive <?php endif; ?>">
                                        <?php echo e($chatUser->email); ?>

                                        <?php if($chatUser->newCount > 0): ?>
                                            <span class="badge badge-primary badge-pill"><?php echo e($chatUser->newCount); ?></span>
                                        <?php endif; ?>
                                    </a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </ul>

                    </div>

                </div>

            <?php endif; ?>


            <div class=" <?php if(count($chatUsers)): ?> col-md-9 <?php else: ?> offset-md-2 col-md-8 <?php endif; ?>  ">
                <div class="card">
                    <div class="card-header">
                        <strong>
                            <?php echo e(Lang::get('chat.messages')); ?>

                        </strong>
                    </div>

                    <div class="card-body messageArea <?php if(isset($chatObj['toUser']->id)): ?> withMessages <?php endif; ?> ">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                        <?php if(isset($chatObj['toUser']->id)): ?>




                            <div class="messageBlock" id="messageBlock">

                                <div id="messagesArea">
                                    <?php if(count($chatObj['messages'])): ?>

                                        <?php $__currentLoopData = $chatObj['messages']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <div data-id="<?php echo e($message->id); ?>"
                                                 class="message <?php if($message->to_id == $currUser->id): ?> in <?php else: ?> out <?php endif; ?>">

                                                <div class="content">

                                                    <?php echo nl2br(htmlspecialchars($message->content)); ?>


                                                    <div class="time">

                                                        <?php echo e($message->created_at->format('d.m.Y h:i')); ?>


                                                    </div>

                                                </div>


                                            </div>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </div>

                                <form method="post" class="sendMessage" action="/sendMessage">

                                    <?php echo csrf_field(); ?>


                                    <input type="hidden" name="to_id" value="<?php echo e($chatObj['toUser']->id); ?>">

                                    <div class="form-group">
                                        <textarea required name="content" class="form-control"
                                                  placeholder="<?php echo e(Lang::get('chat.message')); ?>"></textarea>
                                    </div>

                                    <div class="text-right">
                                        <button class="btn btn-primary" id="sendMessage"
                                                type="submit"><?php echo e(Lang::get('chat.send')); ?></button>
                                    </div>

                                </form>


                            </div>


                        <?php else: ?>
                            <?php echo e(Lang::get('chat.choseDialogue')); ?>

                        <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="loadingBlock">
        <div class="loadingio-spinner-spinner-s97e25y6s1m">
            <div class="ldio-3t5vu773qpj">
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('layouts._errors_form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('styles'); ?>
    <link href="<?php echo e(asset('css/chat.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script src="<?php echo e(asset('js/validate.js')); ?>"></script>
    <script src="<?php echo e(asset('js/chat.js')); ?>"></script>

    <script>

        $(document).ready(function () {

            var toUserId = $('meta[name=toUserId]').attr("content");

            hideLoading();

            setTimeout(function () {
                hideNewMessCount();
            }, 1000);

            if (toUserId > 0) {

                scrollChatToBottom();

                setTimeout(function () {

                    $("#messageBlock").scroll(function () {

                        var scrollTop = $(this).scrollTop();

                        if (scrollTop == 0) {

                            showLoading();

                            var firstMessage = $('#messagesArea .message').first(),
                                firtMessageId = firstMessage.data('id');

                            $.ajax({

                                url: '/loadMessages',

                                type: 'POST',

                                data: {
                                    toUserId: $('meta[name=toUserId]').attr("content"),
                                    toMessageId: firtMessageId,
                                    count: 20
                                },

                                success: function (data) {

                                    if (!isEmpty(data.messageHtml)) {

                                        $('#messagesArea').prepend(data.messageHtml);

                                        $("#messageBlock").scrollTop($('#messagesArea .message[data-id="' + firtMessageId + '"]').offset().top);

                                    }

                                    hideLoading();

                                },

                                error: function (data) {
                                    window.location.reload;
                                }

                            });


                        }


                    });


                }, 200);


            }


            $('#sendMessage').click(function (e) {

                e.preventDefault();

                var form = $(this).closest('form'),
                    messageTextObj = form.find('textarea[name="content"]');

                if (isEmpty(messageTextObj.val())) {

                    var error = ['<?php echo e(Lang::get("chat.contentNull")); ?>'];
                    printErrorMsg(error);

                } else {

                    $.ajax({

                        url: form.attr('action'),

                        type: 'POST',

                        data: form.serialize(),

                        success: function (data) {

                            showLoading();

                            //clear old message
                            messageTextObj.val('');

                            updateMessages();

                            hideLoading();

                        },

                        error: function (data) {
                            window.location.reload;
                        }

                    });

                }


            });


        });

        setInterval(function () {
            updateMessages();
        }, 10000);

    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>