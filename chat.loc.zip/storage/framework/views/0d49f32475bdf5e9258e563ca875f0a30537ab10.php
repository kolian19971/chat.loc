<?php if(count($chatObj['messages'])): ?>

    <?php $__currentLoopData = $chatObj['messages']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div data-id="<?php echo e($message->id); ?>" class="message <?php if($message->to_id == $currUser->id): ?> in <?php else: ?> out <?php endif; ?>">

            <div class="content">

                <?php echo nl2br(htmlspecialchars($message->content)); ?>


                <div class="time">

                    <?php echo e($message->created_at->format('d.m.Y h:i')); ?>


                </div>

            </div>


        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>