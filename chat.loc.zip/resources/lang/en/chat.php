<?php

return [

    'homeTitle' => 'Chat',
    'choseDialogue' => 'You must choose dialogue!',
    'messages' => 'Messages',
    'chatWith' => 'Chat with',
    'send' => 'Send',
    'message' => 'Enter your message',
    'contentNull' => 'Message can not be empty!'

];
